const express = require('express');
const router = express.Router();
const { DB, queryDB, createPage, writeAuditLog } = require('../notion/client');

// GET /api/movements
router.get('/', async (req, res) => {
  try {
    const { tipe } = req.query;
    const filter = tipe ? { property: 'Tipe', select: { equals: tipe } } : {};
    const pages = await queryDB(DB.stockMovement, filter, [{ property: 'Tanggal', direction: 'descending' }]);
    const data = pages.map(p => ({
      no_movement: p.properties['No Movement']?.title?.[0]?.text?.content,
      tanggal:     p.properties['Tanggal']?.date?.start,
      tipe:        p.properties['Tipe']?.select?.name,
      qty_in:      p.properties['Qty In PCS']?.number,
      qty_out:     p.properties['Qty Out PCS']?.number,
      referensi:   p.properties['No Referensi']?.rich_text?.[0]?.text?.content,
      operator:    p.properties['Operator']?.rich_text?.[0]?.text?.content,
    }));
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/movements/summary
router.get('/summary', async (req, res) => {
  try {
    const pages = await queryDB(DB.stockMovement, {});
    const summary = {};
    for (const p of pages) {
      // Ambil item dari relasi (perlu resolve jika mau detail)
      const qtyIn  = p.properties['Qty In PCS']?.number  || 0;
      const qtyOut = p.properties['Qty Out PCS']?.number || 0;
      const ref = p.properties['No Referensi']?.rich_text?.[0]?.text?.content || 'unknown';
      if (!summary[ref]) summary[ref] = { total_in: 0, total_out: 0 };
      summary[ref].total_in  += qtyIn;
      summary[ref].total_out += qtyOut;
    }
    res.json({ data: Object.entries(summary).map(([k, v]) => ({ referensi: k, ...v, stok_tersedia: v.total_in - v.total_out })) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/movements  (manual: ADJUSTMENT / OPNAME)
router.post('/', async (req, res) => {
  try {
    const { tipe, qty_in, qty_out, referensi, operator, catatan } = req.body;
    const seq = Date.now().toString().slice(-6);
    const no_mv = `SM-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${seq.slice(-3)}`;
    const page = await createPage(DB.stockMovement, {
      'No Movement': { title: [{ text: { content: no_mv } }] },
      'Tanggal':     { date: { start: new Date().toISOString().slice(0,10) } },
      'Tipe':        { select: { name: tipe } },
      'Qty In PCS':  { number: qty_in  || 0 },
      'Qty Out PCS': { number: qty_out || 0 },
      'No Referensi':{ rich_text: [{ text: { content: referensi || '' } }] },
      'Operator':    { rich_text: [{ text: { content: operator } }] },
    });
    await writeAuditLog({
      action: 'CREATE', module: 'Stock Movement', noRecord: no_mv,
      field: tipe, nilaiLama: '-', nilaiBaru: `in:${qty_in||0} out:${qty_out||0}`,
      operator, catatan: catatan || '',
    });
    res.status(201).json({ no_movement: no_mv, notion_url: page.url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
