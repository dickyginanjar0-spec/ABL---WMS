const express = require('express');
const router = express.Router();
const { DB, queryDB, createPage, updatePage, writeAuditLog } = require('../notion/client');

// GET /api/inbound
router.get('/', async (req, res) => {
  try {
    const { status } = req.query;
    const filter = status ? { property: 'Status', status: { equals: status } } : {};
    const pages = await queryDB(DB.inboundGR, filter, [{ property: 'Tanggal Terima', direction: 'descending' }]);
    const data = pages.map(p => ({
      no_gr:       p.properties['No GR']?.title?.[0]?.text?.content,
      notion_url:  p.url,
      tgl_terima:  p.properties['Tanggal Terima']?.date?.start,
      division:    p.properties['Divisi']?.select?.name,
      qty_pcs:     p.properties['Qty PCS']?.number,
      qty_karton:  p.properties['Qty Karton']?.number,
      status:      p.properties['Status']?.status?.name,
      operator:    p.properties['Operator']?.rich_text?.[0]?.text?.content,
    }));
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/inbound
router.post('/', async (req, res) => {
  try {
    const { tgl_terima, division, qty_pcs, qty_karton, operator, catatan } = req.body;
    const seq = Date.now().toString().slice(-6);
    const no_gr = `GR-${tgl_terima.replace(/-/g,'')}-${seq.slice(-3)}`;
    const page = await createPage(DB.inboundGR, {
      'No GR':        { title: [{ text: { content: no_gr } }] },
      'Tanggal Terima': { date: { start: tgl_terima } },
      'Divisi':       { select: { name: division } },
      'Qty PCS':      { number: qty_pcs },
      'Qty Karton':   { number: qty_karton },
      'Status':       { status: { name: 'Pending' } },
      'Operator':     { rich_text: [{ text: { content: operator } }] },
      'Catatan':      { rich_text: [{ text: { content: catatan || '' } }] },
    });
    const log = await writeAuditLog({
      action: 'CREATE', module: 'Inbound GR', noRecord: no_gr,
      field: 'Status', nilaiLama: '-', nilaiBaru: 'Pending', operator,
    });
    res.status(201).json({ no_gr, notion_url: page.url, status: 'Pending', audit_log_id: log.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/inbound/:no_gr/status
router.patch('/:no_gr/status', async (req, res) => {
  try {
    const { no_gr } = req.params;
    const { status, operator } = req.body;
    // Cari halaman GR
    const pages = await queryDB(DB.inboundGR, {
      property: 'No GR', title: { equals: no_gr },
    });
    if (!pages.length) return res.status(404).json({ error: 'GR tidak ditemukan' });
    const page = pages[0];
    const oldStatus = page.properties['Status']?.status?.name;
    await updatePage(page.id, { 'Status': { status: { name: status } } });
    await writeAuditLog({
      action: 'STATUS_CHANGE', module: 'Inbound GR', noRecord: no_gr,
      field: 'Status', nilaiLama: oldStatus, nilaiBaru: status, operator,
    });
    // Side effect: jika Done, buat Stock Movement
    if (status === 'Done') {
      const qty = page.properties['Qty PCS']?.number || 0;
      const seq = Date.now().toString().slice(-6);
      await createPage(DB.stockMovement, {
        'No Movement': { title: [{ text: { content: `SM-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${seq.slice(-3)}` } }] },
        'Tanggal':     { date: { start: new Date().toISOString().slice(0,10) } },
        'Tipe':        { select: { name: 'INBOUND' } },
        'Qty In PCS':  { number: qty },
        'Qty Out PCS': { number: 0 },
        'No Referensi':{ rich_text: [{ text: { content: no_gr } }] },
        'Operator':    { rich_text: [{ text: { content: operator } }] },
      });
    }
    res.json({ no_gr, status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
