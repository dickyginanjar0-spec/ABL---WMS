const express = require('express');
const router = express.Router();
const { DB, queryDB, updatePage } = require('../notion/client');

// GET /api/audit
router.get('/', async (req, res) => {
  try {
    const { module, action, verified } = req.query;
    const filters = [];
    if (module)   filters.push({ property: 'Module', select: { equals: module } });
    if (action)   filters.push({ property: 'Action', select: { equals: action } });
    if (verified !== undefined)
      filters.push({ property: 'Verified', checkbox: { equals: verified === 'true' } });
    const filter = filters.length > 1 ? { and: filters } : filters[0] || {};
    const pages = await queryDB(DB.auditLog, filter, [{ timestamp: 'descending' }]);
    const data = pages.map(p => ({
      no_audit:    p.properties['No Audit']?.title?.[0]?.text?.content,
      timestamp:   p.created_time,
      action:      p.properties['Action']?.select?.name,
      module:      p.properties['Module']?.select?.name,
      no_record:   p.properties['No Record']?.rich_text?.[0]?.text?.content,
      field_diubah:p.properties['Field Diubah']?.rich_text?.[0]?.text?.content,
      nilai_lama:  p.properties['Nilai Lama']?.rich_text?.[0]?.text?.content,
      nilai_baru:  p.properties['Nilai Baru']?.rich_text?.[0]?.text?.content,
      operator:    p.properties['Operator']?.rich_text?.[0]?.text?.content,
      verified:    p.properties['Verified']?.checkbox,
      catatan:     p.properties['Catatan']?.rich_text?.[0]?.text?.content,
      notion_id:   p.id,
    }));
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/audit/:notion_id/verify
router.patch('/:notion_id/verify', async (req, res) => {
  try {
    const { notion_id } = req.params;
    const { verified } = req.body;
    await updatePage(notion_id, { 'Verified': { checkbox: verified } });
    res.json({ notion_id, verified });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
