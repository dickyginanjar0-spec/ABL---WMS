const express = require('express');
const router = express.Router();
const { DB, queryDB, updatePage, writeAuditLog } = require('../notion/client');

// GET /api/locations
router.get('/', async (req, res) => {
  try {
    const { status, division } = req.query;
    const filters = [];
    if (status)   filters.push({ property: 'Status', select: { equals: status } });
    if (division) filters.push({ property: 'Divisi', select: { equals: division } });
    const filter = filters.length > 1 ? { and: filters } : filters[0] || {};
    const pages = await queryDB(DB.locations, filter);
    const data = pages.map(p => {
      const kap  = p.properties['Kapasitas PCS']?.number || 0;
      const teri = p.properties['Terisi PCS']?.number    || 0;
      return {
        kode_lokasi:     p.properties['Kode Lokasi']?.title?.[0]?.text?.content,
        notion_url:      p.url,
        notion_id:       p.id,
        kode_rak:        p.properties['Kode Rak']?.rich_text?.[0]?.text?.content,
        division:        p.properties['Divisi']?.select?.name,
        product:         p.properties['Product']?.select?.name,
        kapasitas_pcs:   kap,
        terisi_pcs:      teri,
        available_pcs:   kap - teri,
        utilization_pct: kap > 0 ? Math.round((teri / kap) * 1000) / 10 : 0,
        status:          p.properties['Status']?.select?.name,
      };
    });
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/locations/:kode/stock
router.patch('/:kode/stock', async (req, res) => {
  try {
    const { kode } = req.params;
    const { terisi_pcs, operator, referensi } = req.body;
    const pages = await queryDB(DB.locations, {
      property: 'Kode Lokasi', title: { equals: kode },
    });
    if (!pages.length) return res.status(404).json({ error: 'Lokasi tidak ditemukan' });
    const page = pages[0];
    const old  = page.properties['Terisi PCS']?.number || 0;
    const kap  = page.properties['Kapasitas PCS']?.number || 0;
    let newStatus = 'AVAILABLE';
    if (terisi_pcs >= kap)              newStatus = 'FULL';
    else if (terisi_pcs > 0)            newStatus = 'OCCUPIED';
    await updatePage(page.id, {
      'Terisi PCS': { number: terisi_pcs },
      'Status':     { select: { name: newStatus } },
    });
    await writeAuditLog({
      action: 'UPDATE', module: 'Locations', noRecord: kode,
      field: 'Terisi PCS', nilaiLama: String(old), nilaiBaru: String(terisi_pcs),
      operator, catatan: referensi || '',
    });
    res.json({ kode_lokasi: kode, terisi_pcs, status: newStatus });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
