const express = require('express');
const router = express.Router();
const { DB, queryDB, createPage, updatePage, writeAuditLog } = require('../notion/client');

// GET /api/outbound
router.get('/', async (req, res) => {
  try {
    const { status, division } = req.query;
    const filter = { and: [] };
    if (status)   filter.and.push({ property: 'Status', status: { equals: status } });
    if (division) filter.and.push({ property: 'Divisi', select: { equals: division } });
    const pages = await queryDB(DB.outboundDO, filter.and.length ? filter : {},
      [{ property: 'Tanggal Request', direction: 'descending' }]);
    const data = pages.map(p => ({
      no_do:        p.properties['No DO']?.title?.[0]?.text?.content,
      notion_url:   p.url,
      tgl_request:  p.properties['Tanggal Request']?.date?.start,
      division:     p.properties['Divisi']?.select?.name,
      qty_request:  p.properties['Qty Request PCS']?.number,
      qty_picked:   p.properties['Qty Picked PCS']?.number,
      destination:  p.properties['Tujuan']?.rich_text?.[0]?.text?.content,
      pic:          p.properties['PIC']?.rich_text?.[0]?.text?.content,
      status:       p.properties['Status']?.status?.name,
    }));
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/outbound
router.post('/', async (req, res) => {
  try {
    const { tgl_request, division, qty_request, destination, pic, catatan } = req.body;
    const seq = String(Math.floor(Math.random() * 900) + 100).padStart(6, '0');
    const no_do = `DO-KALBE-${seq}`;
    const page = await createPage(DB.outboundDO, {
      'No DO':            { title: [{ text: { content: no_do } }] },
      'Tanggal Request':  { date: { start: tgl_request } },
      'Divisi':           { select: { name: division } },
      'Qty Request PCS':  { number: qty_request },
      'Tujuan':           { rich_text: [{ text: { content: destination } }] },
      'PIC':              { rich_text: [{ text: { content: pic } }] },
      'Status':           { status: { name: 'REQUEST' } },
      'Catatan':          { rich_text: [{ text: { content: catatan || '' } }] },
    });
    const log = await writeAuditLog({
      action: 'CREATE', module: 'Outbound DO', noRecord: no_do,
      field: 'Status', nilaiLama: '-', nilaiBaru: 'REQUEST', operator: pic,
    });
    res.status(201).json({ no_do, notion_url: page.url, status: 'REQUEST', audit_log_id: log.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/outbound/:no_do/status
router.patch('/:no_do/status', async (req, res) => {
  try {
    const { no_do } = req.params;
    const { status, qty_picked, operator } = req.body;
    const pages = await queryDB(DB.outboundDO, {
      property: 'No DO', title: { equals: no_do },
    });
    if (!pages.length) return res.status(404).json({ error: 'DO tidak ditemukan' });
    const page = pages[0];
    const oldStatus = page.properties['Status']?.status?.name;
    const props = { 'Status': { status: { name: status } } };
    if (qty_picked !== undefined) props['Qty Picked PCS'] = { number: qty_picked };
    await updatePage(page.id, props);

    // Validasi selisih saat PACKING
    if (status === 'PACKING') {
      const qtyReq = page.properties['Qty Request PCS']?.number || 0;
      const qtyPick = qty_picked ?? page.properties['Qty Picked PCS']?.number ?? 0;
      if (qtyPick < qtyReq) {
        // Catat selisih di audit log
        await writeAuditLog({
          action: 'UPDATE', module: 'Outbound DO', noRecord: no_do,
          field: 'Qty Picked PCS', nilaiLama: String(qtyReq), nilaiBaru: String(qtyPick),
          operator, catatan: `Selisih ${qtyReq - qtyPick} PCS`,
        });
      }
    }

    await writeAuditLog({
      action: 'STATUS_CHANGE', module: 'Outbound DO', noRecord: no_do,
      field: 'Status', nilaiLama: oldStatus, nilaiBaru: status, operator,
    });
    res.json({ no_do, status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
