const express = require('express');
const router = express.Router();
const { DB, queryDB, createPage, updatePage, writeAuditLog } = require('../notion/client');

// GET /api/items
router.get('/', async (req, res) => {
  try {
    const { division, status } = req.query;
    const filter = { and: [] };
    if (division) filter.and.push({ property: 'Divisi', select: { equals: division } });
    if (status)   filter.and.push({ property: 'Status', select: { equals: status } });
    const pages = await queryDB(DB.items, filter.and.length ? filter : {});
    const data = pages.map(p => ({
      id:             p.properties['SKU']?.rich_text?.[0]?.text?.content,
      notion_url:     p.url,
      nama_item:      p.properties['Nama Item']?.title?.[0]?.text?.content,
      sku:            p.properties['SKU']?.rich_text?.[0]?.text?.content,
      customer:       p.properties['Customer']?.select?.name,
      division:       p.properties['Divisi']?.select?.name,
      product:        p.properties['Product']?.select?.name,
      tipe_item:      p.properties['Tipe Item']?.select?.name,
      uom:            p.properties['UOM']?.select?.name,
      pcs_per_karton: p.properties['PCS per Karton']?.number,
      status:         p.properties['Status']?.select?.name,
    }));
    res.json({ data, total: data.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/items
router.post('/', async (req, res) => {
  try {
    const { nama_item, sku, customer, division, product, tipe_item, uom, pcs_per_karton } = req.body;
    const page = await createPage(DB.items, {
      'Nama Item':      { title: [{ text: { content: nama_item } }] },
      'SKU':            { rich_text: [{ text: { content: sku } }] },
      'Customer':       { select: { name: customer } },
      'Divisi':         { select: { name: division } },
      'Product':        { select: { name: product } },
      'Tipe Item':      { select: { name: tipe_item } },
      'UOM':            { select: { name: uom } },
      'PCS per Karton': { number: pcs_per_karton },
      'Status':         { select: { name: 'Active' } },
    });
    const log = await writeAuditLog({
      action: 'CREATE', module: 'Items', noRecord: sku,
      field: 'Status', nilaiLama: '-', nilaiBaru: 'Active',
      operator: req.operator,
    });
    res.status(201).json({ id: sku, notion_url: page.url, audit_log_id: log.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
