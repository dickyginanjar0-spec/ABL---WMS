const jwt = require('jsonwebtoken');

function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token tidak ditemukan' });
  }
  const token = header.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.operator = payload.operator;
    req.role = payload.role;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token invalid atau expired' });
  }
}

module.exports = authMiddleware;
