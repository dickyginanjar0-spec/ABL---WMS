require('dotenv').config();
const express = require('express');
const jwt = require('jsonwebtoken');
const auth = require('./middleware/auth');

const app = express();
app.use(express.json());

// Auth
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  // TODO: validasi dari database operator
  if (!username || !password) return res.status(400).json({ error: 'Username dan password wajib diisi' });
  const token = jwt.sign(
    { operator: username, role: 'operator' },
    process.env.JWT_SECRET,
    { expiresIn: '24h' }
  );
  res.json({ token, operator: username, role: 'operator' });
});

// Routes (semua butuh auth)
app.use('/api/items',     auth, require('./routes/items'));
app.use('/api/locations', auth, require('./routes/locations'));
app.use('/api/inbound',   auth, require('./routes/inbound'));
app.use('/api/movements', auth, require('./routes/movements'));
app.use('/api/outbound',  auth, require('./routes/outbound'));
app.use('/api/audit',     auth, require('./routes/audit'));

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`ABL WMS API running on port ${PORT}`));
