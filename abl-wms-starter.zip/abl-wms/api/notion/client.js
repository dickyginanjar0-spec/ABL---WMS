const { Client } = require('@notionhq/client');

const notion = new Client({ auth: process.env.NOTION_API_KEY });

const DB = {
  items:         process.env.DB_ITEMS,
  locations:     process.env.DB_LOCATIONS,
  inboundGR:     process.env.DB_INBOUND_GR,
  stockMovement: process.env.DB_STOCK_MOVEMENT,
  outboundDO:    process.env.DB_OUTBOUND_DO,
  auditLog:      process.env.DB_AUDIT_LOG,
};

// ── Helpers ──────────────────────────────────────────────
async function queryDB(dbId, filter = {}, sorts = []) {
  const res = await notion.databases.query({
    database_id: dbId,
    filter,
    sorts,
  });
  return res.results;
}

async function createPage(dbId, properties, children = []) {
  return notion.pages.create({
    parent: { database_id: dbId },
    properties,
    children,
  });
}

async function updatePage(pageId, properties) {
  return notion.pages.update({ page_id: pageId, properties });
}

async function addComment(pageId, text) {
  return notion.comments.create({
    parent: { page_id: pageId },
    rich_text: [{ type: 'text', text: { content: text } }],
  });
}

// ── Audit Log ─────────────────────────────────────────────
async function writeAuditLog({ action, module, noRecord, field, nilaiLama, nilaiBaru, operator, catatan = '' }) {
  const ts = new Date().toISOString().replace('T', '-').slice(0, 16);
  const noAudit = `LOG-${Date.now().toString().slice(-6)}`;
  return createPage(DB.auditLog, {
    'No Audit':     { title: [{ text: { content: noAudit } }] },
    'Action':       { select: { name: action } },
    'Module':       { select: { name: module } },
    'No Record':    { rich_text: [{ text: { content: noRecord } }] },
    'Field Diubah': { rich_text: [{ text: { content: field } }] },
    'Nilai Lama':   { rich_text: [{ text: { content: nilaiLama } }] },
    'Nilai Baru':   { rich_text: [{ text: { content: nilaiBaru } }] },
    'Operator':     { rich_text: [{ text: { content: operator } }] },
    'Catatan':      { rich_text: [{ text: { content: catatan } }] },
  });
}

module.exports = { notion, DB, queryDB, createPage, updatePage, addComment, writeAuditLog };
