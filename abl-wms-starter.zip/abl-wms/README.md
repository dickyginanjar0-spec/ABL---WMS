# ABL WMS — Warehouse Management System
**Customer: KALBE** | Gudang: ABL

Sistem manajemen gudang berbasis Notion + REST API untuk operasional inbound, outbound, stok, dan audit trail customer Kalbe.

---

## 🏗️ Arsitektur

```
GitHub Web App (Next.js / Express)
     │
     ├─ REST API (/api/*)
     │    └─ Notion API Client → Notion Databases
     │
     └─ Dashboard (abl-dashboard.html)
          └─ Embed di Notion: ABL Control Tower
```

## 📦 Notion Databases

| Database | Fungsi |
|---|---|
| Items | Master SKU Kalbe (ETICAL & OTC/SAKA) |
| Locations | Rack & bin management |
| Inbound GR | Penerimaan barang masuk |
| Stock Movement | Mutasi stok (source of truth) |
| Outbound DO | Pipeline delivery order |
| Audit Log | Trail semua perubahan |

## 🚀 Quick Start

```bash
npm install
cp .env.example .env
# Isi NOTION_API_KEY dan DATABASE_IDs di .env
node api/server.js
```

## 📄 API Endpoints

| Method | Endpoint | Deskripsi |
|---|---|---|
| GET | /api/items | List semua SKU |
| POST | /api/items | Tambah SKU baru |
| GET | /api/locations | List semua rak |
| GET | /api/inbound | List semua GR |
| POST | /api/inbound | Buat GR baru |
| PATCH | /api/inbound/:no_gr/status | Update status GR |
| GET | /api/movements | Feed mutasi stok |
| GET | /api/movements/summary | Ringkasan stok per SKU |
| POST | /api/outbound | Buat DO baru |
| PATCH | /api/outbound/:no_do/status | Advance pipeline DO |
| GET | /api/audit | Trail perubahan |
| PATCH | /api/audit/:id/verify | Verifikasi audit log |

Detail lengkap: lihat `docs/api-spec.md`

## 🤖 Notion Agent

**ABL DO Triage Agent** berjalan otomatis di Notion:
- Trigger saat DO baru dibuat → cek stok, validasi item, komentar triage
- Trigger saat status DO berubah → deteksi selisih picking, notifikasi operator

## 🔗 Links

- Notion Workspace: https://notion.so
- API Spec: `docs/api-spec.md`
- Dashboard: `dashboard/abl-dashboard.html`
